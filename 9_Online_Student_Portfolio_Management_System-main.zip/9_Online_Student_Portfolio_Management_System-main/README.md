GROUP MEMBERS:
•	PRANIL PATIL
•	AKASH PATIL
•	SAHIL SHETTY
•	SUSHANT WAGHMARE

With the help of this project, we want to make the workload of institute easy so that they don’t have to struggle with the certificates of students. In this project we have given student and institute login pages and and with the help of this they can get into their next respective pages. Institute has been given the main right to request for the certificates of student from different branches and this request will we seen in student panel and students can upload the requested certificate by the institute respectively. Institute and student both can upload, remove and download certificates with the help of this project and this project is more convenient because institute can find certificates in a very sorted order.
